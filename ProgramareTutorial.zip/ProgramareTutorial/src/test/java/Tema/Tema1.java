package Tema;

public class Tema1 {

    //Definesc cateva atribute pt un calculator
}
