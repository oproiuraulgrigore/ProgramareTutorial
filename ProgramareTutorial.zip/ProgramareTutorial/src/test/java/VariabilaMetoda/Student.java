package VariabilaMetoda;

public class Student {

    //Asta ii un test
    //Clasa = un sablon care contine variabile si metode
    //Intr-un fisier Java putemm avea mai multe clase diferentiate prin numele lor
    //O clasa trebuie sa aiba un nume
    //O clasa se recunoaste dupa cuvantul Class
    //Tot timpul o clasa trebuie sa fie publica


    public String Nume;
    public String Prenume;
    public String Adresa;
    public Integer Varsta;
    public Double Inaltime;
    public Float Greutate;
    public Character Gen;






    // Facem o metoda cu return

    public double getBonus() {

        double bonus = 1.000;

        return bonus;

    }

}







